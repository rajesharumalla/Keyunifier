/*
 * keypad.h
 *
 *  Created on: 12-Feb-2026
 *      Author: rajes
 */

#ifndef __KEYPAD_H
#define __KEYPAD_H

#include "stm32f4xx_hal.h"

char Keypad_GetKey(void);

#endif

